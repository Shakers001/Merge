# SMSMerge Android app

SMSMerge is an independent, free-to-use Android bulk SMS app starter with a simple, familiar light interface for bulk messaging. It is inspired by common bulk-SMS workflows and the general layout conventions of established SMS apps and is not affiliated with Mediant Technologies.

## Features included
- Up to **1,000 unique recipients per batch**.
- Up to **500 characters per composed message**. Longer messages are rejected by the app; Android may split a valid 500-character message into multiple SMS parts.
- Select phone contacts (permission requested only when needed).
- Import phone numbers from CSV/text files and `.xlsx` spreadsheets. Import searches the selected file for phone-number-like values; keep phone numbers in a spreadsheet column and test the result before sending.
- Save, load, and delete message templates.
- Save, load, and delete recipient groups locally on the device.
- Local sending history.
- Choose an active SIM subscription where Android/device support allows it, or use the system default.
- Sent/delivery status broadcasts are wired; exact reporting depends on the device, SIM, carrier and network.
- No subscription, premium unlocks, advertising SDKs, or paid app features. Carrier SMS charges may still apply.

## Build APK on GitHub (recommended)
1. Create a new repository on GitHub, for example `SMSMerge`.
2. Upload the contents of this ZIP so that `settings.gradle.kts`, `build.gradle.kts`, `app/`, and `.github/` are at the repository root.
3. Open the repository's **Actions** tab. The workflow named **Build SMSMerge APK** should start after the upload/push. You can also run it manually with **Run workflow**.
4. Open the completed workflow run and download the `SMSMerge-debug-apk` artifact.
5. Download the artifact to your Android phone and install the APK. You may need to allow installation from the app used to download it.

## Build locally
Open the project in Android Studio, allow Gradle sync, then choose **Build > Build APK(s)**.

## Notes and limitations
- This is an initial project and has not been device-tested in this environment. Test with a few consenting numbers before using a large batch.
- Android and mobile operators can throttle or block bulk sending. The 1,000-recipient cap is an app limit, not a guarantee all messages will be accepted. Sending to 1,000 people can incur substantial carrier charges.
- Delivery reports are not supported by every carrier. History records batch submission; individual asynchronous reports are currently stored as the latest status and do not yet update each batch row.
- The spreadsheet importer supports `.xlsx`, CSV and text-like files. Legacy `.xls` binary files are not supported; save them as `.xlsx` or `.csv` first. The importer extracts phone-number-like values from the file, so review imported recipients before sending.
- SMS permission and distribution policies may apply if publishing on Google Play.
