package com.smsmerge.app

import android.Manifest
import android.app.PendingIntent
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import android.telephony.SmsManager
import android.telephony.SubscriptionManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import org.w3c.dom.Element
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory

private const val MAX_RECIPIENTS = 1000
private const val MAX_CHARS = 500
private const val PREFS = "smsmerge_store"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SmsMergeScreen() }
    }
}

private data class ContactItem(val name: String, val number: String)
private data class SimItem(val id: Int, val label: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SmsMergeScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    var numbersText by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var consent by remember { mutableStateOf(false) }
    var sending by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Ready to compose") }
    var showContacts by remember { mutableStateOf(false) }
    var showTemplates by remember { mutableStateOf(false) }
    var showGroups by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    var contacts by remember { mutableStateOf<List<ContactItem>>(emptyList()) }
    var selectedContacts by remember { mutableStateOf(setOf<String>()) }
    var sims by remember { mutableStateOf(listOf<SimItem>()) }
    var selectedSim by remember { mutableIntStateOf(-1) }
    var simMenu by remember { mutableStateOf(false) }
    var templateName by remember { mutableStateOf("") }
    var groupName by remember { mutableStateOf("") }
    var refresh by remember { mutableIntStateOf(0) }

    val recipients = remember(numbersText) { parseNumbers(numbersText) }
    val validNumbers = recipients.filter { it.matches(Regex("^\\+?[0-9]{7,15}$")) }
    val invalidCount = recipients.size - validNumbers.size

    fun toast(s: String) = Toast.makeText(context, s, Toast.LENGTH_LONG).show()
    fun loadSims() {
        sims = try {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) emptyList()
            else {
                val sm = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as SubscriptionManager
                sm.activeSubscriptionInfoList.orEmpty().map { SimItem(it.subscriptionId, "SIM ${it.simSlotIndex + 1} · ${it.carrierName}") }
            }
        } catch (_: Exception) { emptyList() }
        if (selectedSim == -1 && sims.isNotEmpty()) selectedSim = sims.first().id
    }
    LaunchedEffect(Unit) { loadSims() }

    fun sendBulkSms() {
        if (validNumbers.isEmpty()) { toast("Add at least one valid phone number."); return }
        if (recipients.size > MAX_RECIPIENTS) { toast("Maximum $MAX_RECIPIENTS recipients per batch."); return }
        if (message.isBlank() || message.length > MAX_CHARS) { toast("Message must contain 1–$MAX_CHARS characters."); return }
        if (!consent) { toast("Confirm you have permission to message these recipients."); return }
        try {
            val manager = if (Build.VERSION.SDK_INT >= 31) {
                if (selectedSim >= 0) SmsManager.getSmsManagerForSubscriptionId(selectedSim) else context.getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION")
                if (selectedSim >= 0 && Build.VERSION.SDK_INT >= 22) SmsManager.getSmsManagerForSubscriptionId(selectedSim) else SmsManager.getDefault()
            }
            sending = true
            val batchId = System.currentTimeMillis().toString()
            val sentIntent = Intent(context, SmsStatusReceiver::class.java).setAction(SmsStatusReceiver.ACTION_SENT).putExtra("batch", batchId)
            val deliveryIntent = Intent(context, SmsStatusReceiver::class.java).setAction(SmsStatusReceiver.ACTION_DELIVERED).putExtra("batch", batchId)
            var submitted = 0
            validNumbers.forEachIndexed { index, number ->
                val sentPi = PendingIntent.getBroadcast(context, (batchId.hashCode() + index) and 0x7fffffff, sentIntent.putExtra("number", number), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                val deliveryPi = PendingIntent.getBroadcast(context, (batchId.hashCode() + index + validNumbers.size) and 0x7fffffff, deliveryIntent.putExtra("number", number), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                try {
                    val parts = manager.divideMessage(message)
                    if (parts.size > 1) manager.sendMultipartTextMessage(number, null, parts, ArrayList(parts.indices.map { sentPi }), ArrayList(parts.indices.map { deliveryPi }))
                    else manager.sendTextMessage(number, null, message, sentPi, deliveryPi)
                    submitted++
                } catch (_: Exception) { }
            }
            val history = loadJsonArray(prefs, "history")
            history.put(JSONObject().put("time", System.currentTimeMillis()).put("count", submitted).put("message", message).put("sim", sims.firstOrNull { it.id == selectedSim }?.label ?: "Default SIM").put("status", "Submitted to Android; waiting for network status"))
            prefs.edit().putString("history", history.toString()).apply()
            refresh++
            sending = false
            status = "Submitted $submitted of ${validNumbers.size}. Network delivery status may arrive later."
            toast("Submitted $submitted SMS. Your carrier may charge for messages.")
        } catch (e: Exception) {
            sending = false
            status = "Could not send: ${e.localizedMessage ?: "SMS service unavailable"}"
        }
    }

    val sendPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if (granted) sendBulkSms() else toast("SMS permission is required.") }
    val contactsPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { contacts = readContacts(context); showContacts = true } else toast("Contacts permission is needed to choose contacts.")
    }
    val phonePermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if (granted) loadSims() else toast("SIM selection unavailable; Android default SIM will be used.") }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) try {
            val imported = importNumbers(context.contentResolver, uri)
            val merged = (recipients + imported).distinct().take(MAX_RECIPIENTS)
            numbersText = merged.joinToString("\n")
            status = "Imported ${imported.size} number(s). ${merged.size} unique recipient(s) ready."
            toast("Imported ${imported.size} number(s).")
        } catch (e: Exception) { toast("Import failed: ${e.localizedMessage ?: "Unsupported file"}") }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF388E3C), secondary = Color(0xFF2E7D32), background = Color(0xFFF5F6F7), surface = Color(0xFFFFFFFF), onSurface = Color(0xFF202124), onBackground = Color(0xFF202124))) {
        Box(Modifier.fillMaxSize().background(Color(0xFFF5F6F7))) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Surface(shape = RoundedCornerShape(10.dp), color = Color(0xFFE8F5E9), modifier = Modifier.size(52.dp)) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Sms, null, tint = Color(0xFF388E3C), modifier = Modifier.size(29.dp)) } }
                    Column(Modifier.weight(1f)) {
                        Text("SMSMerge", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Color(0xFF202124))
                        Text("Bulk SMS Sender", fontSize = 13.sp, color = Color(0xFF5F6368))
                    }
                    Surface(color = Color(0xFFE8F5E9), shape = RoundedCornerShape(8.dp)) { Text("FREE", Modifier.padding(horizontal = 10.dp, vertical = 6.dp), color = Color(0xFF2E7D32), fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                }
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFFFF)), shape = RoundedCornerShape(12.dp)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MetricCard("RECIPIENTS", "${recipients.size}/$MAX_RECIPIENTS", Modifier.weight(1f))
                        MetricCard("CHARACTERS", "${message.length}/$MAX_CHARS", Modifier.weight(1f))
                    }
                }
                SectionTitle("", "Recipients")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) { contacts = readContacts(context); showContacts = true } else contactsPermission.launch(Manifest.permission.READ_CONTACTS) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Contacts, null); Spacer(Modifier.width(5.dp)); Text("Contacts") }
                    OutlinedButton(onClick = { importLauncher.launch(arrayOf("text/*", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-excel")) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.FileOpen, null); Spacer(Modifier.width(5.dp)); Text("Import file") }
                }
                OutlinedTextField(value = numbersText, onValueChange = { input -> if (parseNumbers(input).size <= MAX_RECIPIENTS) numbersText = input else toast("Maximum $MAX_RECIPIENTS recipients.") }, modifier = Modifier.fillMaxWidth().heightIn(min = 110.dp), label = { Text("Phone numbers") }, placeholder = { Text("Paste numbers or import CSV / Excel (.xlsx)") }, supportingText = { Text("${validNumbers.size} valid • $invalidCount invalid • duplicates removed") }, minLines = 3, shape = RoundedCornerShape(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { templateName = ""; showTemplates = true }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(4.dp)); Text("Templates") }
                    OutlinedButton(onClick = { groupName = ""; showGroups = true }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(4.dp)); Text("Groups") }
                    OutlinedButton(onClick = { showHistory = true; refresh++ }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.History, null); Spacer(Modifier.width(4.dp)); Text("History") }
                }
                SectionTitle("", "Compose message")
                OutlinedTextField(value = message, onValueChange = { if (it.length <= MAX_CHARS) message = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Your SMS") }, placeholder = { Text("Type your message here…") }, minLines = 4, supportingText = { Text("${message.length} of $MAX_CHARS characters") }, shape = RoundedCornerShape(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Sending SIM", color = Color(0xFF202124), fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Box {
                        OutlinedButton(onClick = { if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) phonePermission.launch(Manifest.permission.READ_PHONE_STATE) else { loadSims(); simMenu = true } }) { Text(sims.firstOrNull { it.id == selectedSim }?.label ?: "Default SIM ▾") }
                        DropdownMenu(expanded = simMenu, onDismissRequest = { simMenu = false }) {
                            DropdownMenuItem(text = { Text("Default SIM") }, onClick = { selectedSim = -1; simMenu = false })
                            sims.forEach { sim -> DropdownMenuItem(text = { Text(sim.label) }, onClick = { selectedSim = sim.id; simMenu = false }) }
                        }
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F3F4)), shape = RoundedCornerShape(10.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Before sending", fontWeight = FontWeight.Bold, color = Color(0xFF202124))
                        Text("SMS uses your phone's SIM. Carrier charges and anti-spam limits may apply. A 500-character message can be split into multiple SMS parts.", fontSize = 12.sp, color = Color(0xFF5F6368), lineHeight = 18.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = consent, onCheckedChange = { consent = it }); Text("I have permission to message these recipients.", fontSize = 12.sp, color = Color(0xFF202124)) }
                    }
                }
                Button(onClick = { if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) sendBulkSms() else sendPermission.launch(Manifest.permission.SEND_SMS) }, enabled = !sending && message.isNotBlank() && recipients.isNotEmpty() && recipients.size <= MAX_RECIPIENTS, modifier = Modifier.fillMaxWidth().height(58.dp), shape = RoundedCornerShape(10.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF65D5F7), contentColor = Color(0xFF07111C))) {
                    Icon(Icons.Default.Send, null); Spacer(Modifier.width(10.dp)); Text(if (sending) "SENDING…" else "SEND TO ${recipients.size.coerceAtMost(MAX_RECIPIENTS)} RECIPIENTS", fontWeight = FontWeight.ExtraBold)
                }
                Text(status, color = Color(0xFF5F6368), fontSize = 12.sp)
                Text("SMSMerge is an independent app. Android and mobile networks may restrict bulk SMS; delivery is not guaranteed.", color = Color(0xFF6B7280), fontSize = 10.sp, lineHeight = 14.sp)
            }
        }
    }

    if (showContacts) AlertDialog(onDismissRequest = { showContacts = false }, title = { Text("Choose contacts") }, text = {
        Column {
            Text("Selected: ${selectedContacts.size} / $MAX_RECIPIENTS", fontSize = 12.sp)
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                items(contacts) { contact ->
                    Row(Modifier.fillMaxWidth().clickable { selectedContacts = if (contact.number in selectedContacts) selectedContacts - contact.number else if (selectedContacts.size < MAX_RECIPIENTS) selectedContacts + contact.number else selectedContacts }.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = contact.number in selectedContacts, onCheckedChange = { checked -> selectedContacts = if (checked) (selectedContacts + contact.number).take(MAX_RECIPIENTS).toSet() else selectedContacts - contact.number })
                        Column { Text(contact.name); Text(contact.number, fontSize = 12.sp, color = Color.Gray) }
                    }
                }
            }
        }
    }, confirmButton = { TextButton(onClick = { numbersText = (recipients + selectedContacts).distinct().take(MAX_RECIPIENTS).joinToString("\n"); showContacts = false }) { Text("Add selected") } }, dismissButton = { TextButton(onClick = { showContacts = false }) { Text("Cancel") } })

    if (showTemplates) AlertDialog(onDismissRequest = { showTemplates = false }, title = { Text("Message templates") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = templateName, onValueChange = { templateName = it }, label = { Text("Template name to save") }, singleLine = true)
            Button(onClick = { if (templateName.isNotBlank() && message.isNotBlank()) { val arr = loadJsonArray(prefs, "templates"); arr.put(JSONObject().put("name", templateName.trim()).put("message", message)); prefs.edit().putString("templates", arr.toString()).apply(); refresh++; templateName = ""; toast("Template saved") } else toast("Enter a name and message first") }, modifier = Modifier.fillMaxWidth()) { Text("Save current message") }
            Text("Saved templates", fontWeight = FontWeight.Bold)
            val arr = remember(refresh) { loadJsonArray(prefs, "templates") }
            LazyColumn(Modifier.heightIn(max = 250.dp)) { items((0 until arr.length()).map { arr.getJSONObject(it) }) { item -> Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(item.optString("name")); Text(item.optString("message"), fontSize = 11.sp, maxLines = 2, color = Color.Gray) }; TextButton(onClick = { message = item.optString("message").take(MAX_CHARS); showTemplates = false }) { Text("Use") }; TextButton(onClick = { val now = loadJsonArray(prefs, "templates"); val keep = JSONArray(); for (i in 0 until now.length()) if (now.getJSONObject(i).optString("name") != item.optString("name")) keep.put(now.getJSONObject(i)); prefs.edit().putString("templates", keep.toString()).apply(); refresh++ }) { Text("×") } } } }
        }
    }, confirmButton = { TextButton(onClick = { showTemplates = false }) { Text("Close") } })

    if (showGroups) AlertDialog(onDismissRequest = { showGroups = false }, title = { Text("Recipient groups") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = groupName, onValueChange = { groupName = it }, label = { Text("Group name to save") }, singleLine = true)
            Button(onClick = { if (groupName.isNotBlank() && recipients.isNotEmpty()) { val arr = loadJsonArray(prefs, "groups"); arr.put(JSONObject().put("name", groupName.trim()).put("numbers", recipients.joinToString("\n"))); prefs.edit().putString("groups", arr.toString()).apply(); refresh++; groupName = ""; toast("Group saved") } else toast("Enter a name and recipients first") }, modifier = Modifier.fillMaxWidth()) { Text("Save current recipients") }
            Text("Saved groups", fontWeight = FontWeight.Bold)
            val arr = remember(refresh) { loadJsonArray(prefs, "groups") }
            LazyColumn(Modifier.heightIn(max = 250.dp)) { items((0 until arr.length()).map { arr.getJSONObject(it) }) { item -> Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(item.optString("name")); Text("${parseNumbers(item.optString("numbers")).size} numbers", fontSize = 11.sp, color = Color.Gray) }; TextButton(onClick = { numbersText = (recipients + parseNumbers(item.optString("numbers"))).distinct().take(MAX_RECIPIENTS).joinToString("\n"); showGroups = false }) { Text("Load") }; TextButton(onClick = { val now = loadJsonArray(prefs, "groups"); val keep = JSONArray(); for (i in 0 until now.length()) if (now.getJSONObject(i).optString("name") != item.optString("name")) keep.put(now.getJSONObject(i)); prefs.edit().putString("groups", keep.toString()).apply(); refresh++ }) { Text("×") } } } }
        }
    }, confirmButton = { TextButton(onClick = { showGroups = false }) { Text("Close") } })

    if (showHistory) AlertDialog(onDismissRequest = { showHistory = false }, title = { Text("Sending history") }, text = {
        val arr = remember(refresh) { loadJsonArray(prefs, "history") }
        Column {
            Text("Latest network report: ${prefs.getString("last_status", "No sent/delivery reports received yet")}", fontSize = 11.sp, color = Color(0xFF388E3C))
            Spacer(Modifier.height(8.dp))
            if (arr.length() == 0) Text("No sending batches yet.") else LazyColumn(Modifier.heightIn(max = 380.dp)) { items((0 until arr.length()).reversed().map { arr.getJSONObject(it) }) { item -> Column(Modifier.fillMaxWidth().padding(vertical = 7.dp)) { Text("${item.optInt("count")} recipients · ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(item.optLong("time")))}", fontWeight = FontWeight.SemiBold); Text(item.optString("message"), fontSize = 12.sp, maxLines = 3); Text(item.optString("sim") + " · " + item.optString("status"), fontSize = 10.sp, color = Color.Gray); HorizontalDivider() } } }
        }
    }, confirmButton = { TextButton(onClick = { showHistory = false }) { Text("Close") } })
}

@Composable private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) { Column(modifier.background(Color(0xFFE8F5E9), RoundedCornerShape(14.dp)).padding(13.dp)) { Text(label, fontSize = 9.sp, letterSpacing = 0.sp, color = Color(0xFF5F6368), fontWeight = FontWeight.Bold); Spacer(Modifier.height(5.dp)); Text(value, fontSize = 18.sp, color = Color(0xFF202124), fontWeight = FontWeight.Bold) } }
@Composable private fun SectionTitle(number: String, title: String) { Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) { Text(title, color = Color(0xFF202124), fontWeight = FontWeight.SemiBold, fontSize = 17.sp) } }

private fun parseNumbers(input: String): List<String> = input.split(',', ';', '\n', '\t', ' ', '|').map { it.trim().trim('"', '\'') }.filter { it.isNotBlank() }.distinct()
private fun loadJsonArray(prefs: android.content.SharedPreferences, key: String): JSONArray = try { JSONArray(prefs.getString(key, "[]")) } catch (_: Exception) { JSONArray() }

private fun readContacts(context: Context): List<ContactItem> {
    val result = linkedMapOf<String, ContactItem>()
    val cursor: Cursor? = context.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER), null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC")
    cursor?.use { while (it.moveToNext() && result.size < 5000) { val name = it.getString(0) ?: "Unknown"; val number = it.getString(1)?.replace(" ", "") ?: continue; if (number.isNotBlank()) result.putIfAbsent(number, ContactItem(name, number)) } }
    return result.values.toList()
}

private fun importNumbers(resolver: ContentResolver, uri: Uri): List<String> {
    val name = resolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else "" } ?: ""
    val bytes = resolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Cannot open file")
    val text = if (name.endsWith(".xlsx", true) || bytes.take(4).toByteArray().contentEquals(byteArrayOf(0x50,0x4b,0x03,0x04))) xlsxToText(bytes) else String(bytes, Charsets.UTF_8)
    val numberRegex = Regex("(?<![A-Za-z0-9])\\+?[0-9][0-9 ()-]{5,18}[0-9](?![A-Za-z0-9])")
    return numberRegex.findAll(text).map { it.value.replace(Regex("[ ()-]"), "") }.filter { it.matches(Regex("^\\+?[0-9]{7,15}$")) }.distinct().take(MAX_RECIPIENTS).toList()
}

private fun xlsxToText(bytes: ByteArray): String {
    val entries = mutableMapOf<String, ByteArray>()
    ZipInputStream(bytes.inputStream()).use { zip -> while (true) { val entry = zip.nextEntry ?: break; if (!entry.isDirectory) entries[entry.name] = zip.readBytes(); zip.closeEntry() } }
    fun parseXml(path: String) = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(entries[path]?.inputStream() ?: error("Excel worksheet missing"))
    val shared = mutableListOf<String>()
    entries["xl/sharedStrings.xml"]?.let { data ->
        val doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(data.inputStream())
        val si = doc.getElementsByTagName("si")
        for (i in 0 until si.length) { val node = si.item(i); val t = node.childNodes; val sb = StringBuilder(); for (j in 0 until t.length) if (t.item(j).nodeName == "t") sb.append(t.item(j).textContent); else { val inner = t.item(j).childNodes; for (k in 0 until inner.length) if (inner.item(k).nodeName == "t") sb.append(inner.item(k).textContent) }; shared.add(sb.toString()) }
    }
    val sheetPath = entries.keys.firstOrNull { it.matches(Regex("xl/worksheets/sheet[0-9]+\\.xml")) } ?: error("No worksheet found in Excel file")
    val doc = parseXml(sheetPath)
    val cells = doc.getElementsByTagName("c")
    val out = StringBuilder()
    for (i in 0 until cells.length) {
        val cell = cells.item(i) as? Element ?: continue
        val type = cell.getAttribute("t")
        val v = cell.getElementsByTagName("v").item(0)?.textContent ?: continue
        out.append(if (type == "s") shared.getOrNull(v.toIntOrNull() ?: -1) ?: "" else v).append('\n')
    }
    return out.toString()
}
