package com.smsmerge.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.SmsManager

class SmsStatusReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val status = when (intent.action) {
            ACTION_SENT -> if (resultCode == android.app.Activity.RESULT_OK) "Sent to network" else "Send failed (code $resultCode)"
            ACTION_DELIVERED -> "Delivered (network report)"
            else -> return
        }
        val prefs = context.getSharedPreferences("smsmerge_store", Context.MODE_PRIVATE)
        val key = "last_status"
        prefs.edit().putString(key, "${intent.getStringExtra("number") ?: "Recipient"}: $status").apply()
    }
    companion object {
        const val ACTION_SENT = "com.smsmerge.app.SMS_SENT"
        const val ACTION_DELIVERED = "com.smsmerge.app.SMS_DELIVERED"
    }
}
